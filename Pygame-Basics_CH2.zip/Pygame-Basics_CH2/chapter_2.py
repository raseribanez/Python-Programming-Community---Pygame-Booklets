# Ben Woodfield
# Python Basics - Pygame Chapter 2

'''
    In this lesson we take our template from Chapter One
    and add some animation to it. We will se a background colour
    and have a sprite (character image) moving around the screen
    to give an animated effect.

'''

# This time we will import pygame and sys together
import pygame, sys # sys is used later for a clean exit 
from pygame.locals import *  # (*) means import EVERYTHING from that particular module

# Initialise Pygame
pygame.init()

# Set the Frames Per Second rate
FPS = 30
# Allow Python to use clock count the frame per second rate
fpsClock = pygame.time.Clock()

# Configure the main window settings
DISPLAYSURF = pygame.display.set_mode((400,300), 0, 32)
pygame.display.set_caption('Moving Sprite')

# Create some variables for later use
BLUE = (0, 0, 155)                     # Our backgtound color
spriteImg = pygame.image.load('sprite.png') # The image we are using
spritex = 10                                # movement value for (x)
spritey = 10                                # movement value for (y)
direction = 'right'                         # movement direction

# Heres our Main/Game loop like before, but with a few changes
while True:
    DISPLAYSURF.fill(BLUE)                 # Using our colour variable instead of typing RGB values every time
                                            # This will show a white screen every time the loop runs (30 per second = FPS)
                                        
    if direction == 'right':                # If the sprites moving RIGHT,
        spritex += 5                        # move +5 pixels each step (loop run)
        if spritex == 340:                  # when the sprite reaches 340 pixels,
            direction = 'down'              # turn downwards
    elif direction == 'down':               # If the sprites moving DOWN,
        spritey += 5                        # move +5 pixels each step (loop run)
        if spritey == 220:                  # when the sprite reaches 220 pixels
            direction = 'left'              # turn left
    elif direction == 'left':               # If the sprites moving LEFT, 
        spritex -= 5                        # move -5 pixels each step (loop  run)
        if spritex == 10:                   # when the sprite reaches 10 pixels
            direction = 'up'                # turn up
    elif direction == 'up':                 # If the sprites moving UP
        spritey -= 5                        # move -5 pixels each step (loop turn)
        if spritey == 10:                   # when the sprite reaches 10 pixels
            direction = 'right'             # turn right - the main loop restarts

    # Display our image every time the loop runs
    DISPLAYSURF.blit(spriteImg, (spritex, spritey))

    # Check for an event - in this case the player exiting
    # and close the app cleanly using sys
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

    # Update display
    pygame.display.update()
    fpsClock.tick(FPS)

    
    
